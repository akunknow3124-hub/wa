import Database from 'better-sqlite3';
const db = new Database('webauth.db');
db.prepare('CREATE TABLE IF NOT EXISTS totp (id INTEGER PRIMARY KEY,name TEXT,secret TEXT)').run();
db.prepare('CREATE TABLE IF NOT EXISTS passwords (id INTEGER PRIMARY KEY,site TEXT,username TEXT,password TEXT)').run();
db.prepare('CREATE TABLE IF NOT EXISTS ids (id INTEGER PRIMARY KEY,id_name TEXT,id_value TEXT)').run();
export default ()=>db;
