import express from 'express';
import session from 'express-session';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dbInit from './db.js';
import admin from 'firebase-admin';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(helmet());
app.use(cors());
app.use(bodyParser.json());
app.use(cookieParser());
app.use(session({secret:'secret',resave:false,saveUninitialized:true}));
app.use(express.static(path.join(__dirname,'public')));
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));

// Firebase Admin
try{
    const serviceAccount = await import('./firebase-admin.json', {assert:{type:'json'}});
    admin.initializeApp({credential: admin.credential.cert(serviceAccount.default)});
}catch(e){console.log('Missing firebase-admin.json file!');}

// Database
const db = dbInit();

// Routes
app.get('/', (req,res)=>res.redirect('/login'));
app.get('/login',(req,res)=>res.render('login'));
app.get('/register',(req,res)=>res.render('register'));
app.get('/dashboard',(req,res)=>{
    if(!req.session.user) return res.redirect('/login');
    res.render('dashboard');
});

// Logout
app.post('/logout',(req,res)=>{req.session.destroy();res.json({success:true});});

app.listen(8080,()=>console.log('Server running on port 8080'));
